// Ejercicio 2 de la sesion 5 del modulo 2
// Jose Miguel Hernandez Garcia
// 2º C

#include <stdio.h>
#include <signal.h>

static int i;
static int contadores[31];

static void handler (int i){

    contadores[i]++;
    printf("\n La señal %d , se ha realizado %d veces. ", i, contadores[i]);
}

int main(){

    struct sigaction sa;
    sa.sa_handler = handler; // ignora la señal
    sigemptyset(&sa.sa_mask);

    //Reiniciar las funciones que hayan sido interrumpidas por un manejador
    sa.sa_flags = SA_RESTART;

    int contadores[31];

    for (i = 1; i <= 31; i++)
        contadores[i] = 0;

    int j;

    for (j = 1 ; j <= 60; j++){

        if (sigaction(j, &sa, NULL) == -1)
            printf("error en el manejador");
    } while(1);
}
